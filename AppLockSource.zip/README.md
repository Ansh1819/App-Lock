# App Lock (Android tablet)
1. Open this folder in Android Studio, let Gradle sync, press Run (or Build > Build APK).
2. Open App Lock, create the master password, set a PIN and/or pattern.
3. Tap "Enable protection", turn on "App Lock" under Accessibility.
4. Tap apps in the list to lock them (tap cycles: PIN -> Pattern -> off).
