package com.applock

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.widget.Toast

/** Shown on top of a locked app; asks for that app's PIN or pattern. */
class LockActivity : Activity() {
    private lateinit var pkg: String

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        pkg = intent.getStringExtra("pkg") ?: return finish()
        val mode = intent.getStringExtra("mode") ?: Store.PIN
        val store = Store(this)
        val col = Ui.column(this)
        col.addView(Ui.title(this, "Locked – enter your ${if (mode == Store.PIN) "PIN" else "pattern"}"))
        fun result(ok: Boolean) {
            if (ok) { Store.unlockedPkg = pkg; finish() }
            else Toast.makeText(this, "Wrong, try again", Toast.LENGTH_SHORT).show()
        }
        if (mode == Store.PIN) col.addView(Ui.pinPad(this) { result(store.check(Store.PIN, it)) })
        else col.addView(PatternView(this) { result(store.check(Store.PATTERN, it)) })
        setContentView(col)
    }

    override fun onBackPressed() {
        startActivity(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        finish()
    }
}
