package com.applock

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.view.accessibility.AccessibilityEvent

/** Watches which app comes to the foreground and shows LockActivity for locked ones. */
class LockService : AccessibilityService() {
    override fun onAccessibilityEvent(e: AccessibilityEvent) {
        if (e.eventType != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) return
        val pkg = e.packageName?.toString() ?: return
        if (pkg == packageName || pkg == "com.android.systemui") return
        val mode = Store(this).lockedApps()[pkg]
        if (mode == null) {
            // Ignore keyboards so typing inside an unlocked locked-app doesn't re-lock it.
            val ime = android.provider.Settings.Secure.getString(contentResolver, android.provider.Settings.Secure.DEFAULT_INPUT_METHOD)
            if (ime == null || !ime.startsWith("$pkg/")) Store.unlockedPkg = null
            return
        }
        if (Store.unlockedPkg == pkg) return
        startActivity(Intent(this, LockActivity::class.java)
            .putExtra("pkg", pkg).putExtra("mode", mode)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP))
    }
    override fun onInterrupt() {}
}
