package com.applock

import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.widget.*

class MainActivity : Activity() {
    private lateinit var store: Store
    private var authed = false

    override fun onCreate(b: Bundle?) { super.onCreate(b); store = Store(this) }
    override fun onStart() { super.onStart(); if (authed) showHome() else showGate() }
    override fun onStop() { super.onStop(); authed = false }

    // --- master password gate ---
    private fun showGate() {
        val col = Ui.column(this); col.gravity = Gravity.CENTER
        val setup = !store.has(Store.PASSWORD)
        col.addView(Ui.title(this, if (setup) "Create a password for App Lock" else "Enter password"))
        val pw = EditText(this).apply { inputType = 0x81; hint = "Password" }
        col.addView(pw)
        val pw2 = EditText(this).apply { inputType = 0x81; hint = "Confirm password"; visibility = if (setup) View.VISIBLE else View.GONE }
        col.addView(pw2)
        col.addView(Button(this).apply {
            text = if (setup) "Save" else "Unlock"
            setOnClickListener {
                val s = pw.text.toString()
                if (setup) {
                    if (s.length < 4) return@setOnClickListener toast("Use at least 4 characters")
                    if (s != pw2.text.toString()) return@setOnClickListener toast("Passwords don't match")
                    store.set(Store.PASSWORD, s); authed = true; showHome()
                } else if (store.check(Store.PASSWORD, s)) { authed = true; showHome() } else toast("Wrong password")
            }
        })
        setContentView(col)
    }

    // --- main screen ---
    private fun showHome() {
        val root = Ui.column(this)
        root.addView(Ui.title(this, "App Lock"))
        root.addView(TextView(this).apply {
            text = if (serviceOn()) "Protection is ON" else "Protection is OFF – tap below and enable \"App Lock\" in Accessibility"
        })
        if (!serviceOn()) root.addView(Button(this).apply {
            text = "Enable protection"; setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        })
        val row = LinearLayout(this)
        row.addView(Button(this).apply { text = if (store.has(Store.PIN)) "Change PIN" else "Set PIN"; setOnClickListener { setPin() } })
        row.addView(Button(this).apply { text = if (store.has(Store.PATTERN)) "Change pattern" else "Set pattern"; setOnClickListener { setPattern() } })
        row.addView(Button(this).apply { text = "Change password"; setOnClickListener { changePassword() } })
        root.addView(row)
        root.addView(TextView(this).apply { text = "Tap an app to lock it. Tap again to switch PIN / pattern / unlock." })

        val pm = packageManager
        val apps = pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0)
            .map { it.activityInfo.packageName to it.loadLabel(pm).toString() }
            .filter { it.first != packageName }.distinctBy { it.first }.sortedBy { it.second.lowercase() }
        val list = ListView(this)
        fun label(a: Pair<String, String>) = a.second + when (store.lockedApps()[a.first]) {
            Store.PIN -> "   🔒 PIN"; Store.PATTERN -> "   🔒 Pattern"; else -> ""
        }
        val ad = object : ArrayAdapter<Pair<String, String>>(this, android.R.layout.simple_list_item_1, apps) {
            override fun getView(i: Int, v: View?, p: android.view.ViewGroup): View =
                (super.getView(i, v, p) as TextView).also { it.text = label(apps[i]) }
        }
        list.adapter = ad
        list.setOnItemClickListener { _, _, i, _ ->
            val pkg = apps[i].first
            val next = when (store.lockedApps()[pkg]) { null -> Store.PIN; Store.PIN -> Store.PATTERN; else -> null }
            if (next == Store.PIN && !store.has(Store.PIN)) return@setOnItemClickListener toast("Set a PIN first")
            if (next == Store.PATTERN && !store.has(Store.PATTERN)) {
                // skip pattern if none set
                store.setLock(pkg, null)
                return@setOnItemClickListener ad.notifyDataSetChanged()
            }
            store.setLock(pkg, next); ad.notifyDataSetChanged()
        }
        root.addView(list, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
    }

    private fun serviceOn(): Boolean =
        (Settings.Secure.getString(contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES) ?: "")
            .contains("$packageName/$packageName.LockService")

    private fun setPin() {
        Ui.prompt(this, "New PIN (4-12 digits)", false) { a ->
            if (!a.matches(Regex("\\d{4,12}"))) return@prompt toast("PIN must be 4-12 digits")
            Ui.prompt(this, "Confirm PIN", false) { b ->
                if (a == b) { store.set(Store.PIN, a); toast("PIN saved"); showHome() } else toast("PINs don't match")
            }
        }
    }

    private fun setPattern() {
        var first: String? = null
        val col = Ui.column(this)
        val msg = Ui.title(this, "Draw a pattern (at least 4 dots)")
        col.addView(msg)
        col.addView(PatternView(this) { p ->
            if (p.length < 4) return@PatternView toast("Connect at least 4 dots")
            if (first == null) { first = p; msg.text = "Draw it again to confirm" }
            else if (first == p) { store.set(Store.PATTERN, p); toast("Pattern saved"); showHome() }
            else { first = null; msg.text = "Didn't match. Draw a pattern again"; }
        })
        col.addView(Button(this).apply { text = "Cancel"; setOnClickListener { showHome() } })
        setContentView(col)
    }

    private fun changePassword() {
        Ui.prompt(this, "New password", true) { a ->
            if (a.length < 4) return@prompt toast("Use at least 4 characters")
            store.set(Store.PASSWORD, a); toast("Password changed")
        }
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()
}
