package com.applock

import android.app.Activity
import android.app.AlertDialog
import android.view.Gravity
import android.view.View
import android.widget.*

object Ui {
    fun dp(a: Activity, v: Int) = (v * a.resources.displayMetrics.density).toInt()

    fun column(a: Activity): LinearLayout = LinearLayout(a).apply {
        orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_HORIZONTAL
        val p = dp(a, 24); setPadding(p, p, p, p)
    }
    fun title(a: Activity, t: String) = TextView(a).apply { text = t; textSize = 22f; gravity = Gravity.CENTER; setPadding(0, 0, 0, dp(a, 16)) }

    /** PIN pad: calls onEntered with the digits when OK is pressed. */
    fun pinPad(a: Activity, onEntered: (String) -> Unit): View {
        val box = column(a); val sb = StringBuilder()
        val shown = TextView(a).apply { textSize = 28f; gravity = Gravity.CENTER; text = " " }
        box.addView(shown)
        fun refresh() { shown.text = if (sb.isEmpty()) " " else "●".repeat(sb.length) }
        val keys = listOf("1","2","3","4","5","6","7","8","9","⌫","0","OK")
        val grid = GridLayout(a).apply { columnCount = 3 }
        for (k in keys) grid.addView(Button(a).apply {
            text = k; textSize = 20f
            layoutParams = GridLayout.LayoutParams().apply { width = dp(a, 90); height = dp(a, 70) }
            setOnClickListener {
                when (k) {
                    "⌫" -> if (sb.isNotEmpty()) sb.deleteCharAt(sb.length - 1)
                    "OK" -> { val s = sb.toString(); sb.clear(); onEntered(s) }
                    else -> if (sb.length < 12) sb.append(k)
                }
                refresh()
            }
        })
        box.addView(grid); return box
    }

    fun prompt(a: Activity, title: String, password: Boolean, onOk: (String) -> Unit) {
        val et = EditText(a).apply {
            if (password) inputType = android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_VARIATION_PASSWORD
        }
        AlertDialog.Builder(a).setTitle(title).setView(et).setPositiveButton("OK") { _, _ -> onOk(et.text.toString()) }
            .setNegativeButton("Cancel", null).show()
    }
}
