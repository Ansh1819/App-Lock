package com.applock

import android.content.Context
import android.graphics.*
import android.view.MotionEvent
import android.view.View

/** 3x3 pattern grid. Reports the pattern as digits "0".."8". */
class PatternView(ctx: Context, private val onDone: (String) -> Unit) : View(ctx) {
    private val dot = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.DKGRAY }
    private val on = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.rgb(25, 118, 210) }
    private val line = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.rgb(25, 118, 210); strokeWidth = 12f; strokeCap = Paint.Cap.ROUND
    }
    private val sel = mutableListOf<Int>()
    private var cx = 0f; private var cy = 0f

    private fun pt(i: Int): PointF {
        val s = minOf(width, height) / 3f
        return PointF(s * (i % 3 + 0.5f) + (width - 3 * s) / 2, s * (i / 3 + 0.5f) + (height - 3 * s) / 2)
    }
    override fun onMeasure(w: Int, h: Int) {
        val s = minOf(MeasureSpec.getSize(w), 900); setMeasuredDimension(s, s)
    }
    override fun onDraw(c: Canvas) {
        for (k in 1 until sel.size) { val a = pt(sel[k - 1]); val b = pt(sel[k]); c.drawLine(a.x, a.y, b.x, b.y, line) }
        if (sel.isNotEmpty() && isPressed) { val a = pt(sel.last()); c.drawLine(a.x, a.y, cx, cy, line) }
        for (i in 0..8) { val p = pt(i); c.drawCircle(p.x, p.y, if (i in sel) 26f else 18f, if (i in sel) on else dot) }
    }
    override fun onTouchEvent(e: MotionEvent): Boolean {
        cx = e.x; cy = e.y
        when (e.action) {
            MotionEvent.ACTION_DOWN -> { sel.clear(); isPressed = true; hit() }
            MotionEvent.ACTION_MOVE -> hit()
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                isPressed = false
                val r = sel.joinToString(""); sel.clear()
                if (r.isNotEmpty()) onDone(r)
            }
        }
        invalidate(); return true
    }
    private fun hit() {
        for (i in 0..8) if (i !in sel) {
            val p = pt(i)
            if (Math.hypot((cx - p.x).toDouble(), (cy - p.y).toDouble()) < width / 8.0) sel.add(i)
        }
    }
}
