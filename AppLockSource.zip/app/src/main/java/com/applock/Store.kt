package com.applock

import android.content.Context
import java.security.MessageDigest
import java.security.SecureRandom

/** Stores salted hashes of the master password, PIN and pattern, plus locked apps. */
class Store(ctx: Context) {
    private val p = ctx.applicationContext.getSharedPreferences("applock", Context.MODE_PRIVATE)

    private fun hash(secret: String, salt: String) =
        MessageDigest.getInstance("SHA-256").digest((salt + secret).toByteArray()).joinToString("") { "%02x".format(it) }

    fun set(key: String, secret: String) {
        val salt = ByteArray(16).also { SecureRandom().nextBytes(it) }.joinToString("") { "%02x".format(it) }
        p.edit().putString("$key.salt", salt).putString("$key.hash", hash(secret, salt)).apply()
    }
    fun has(key: String) = p.contains("$key.hash")
    fun check(key: String, secret: String): Boolean {
        val salt = p.getString("$key.salt", null) ?: return false
        return hash(secret, salt) == p.getString("$key.hash", null)
    }

    /** package -> "pin" or "pattern" */
    fun lockedApps(): Map<String, String> =
        p.getStringSet("locked", emptySet())!!.associate { val (a, b) = it.split("|"); a to b }
    fun setLock(pkg: String, mode: String?) {
        val m = lockedApps().toMutableMap()
        if (mode == null) m.remove(pkg) else m[pkg] = mode
        p.edit().putStringSet("locked", m.map { "${it.key}|${it.value}" }.toSet()).apply()
    }

    companion object {
        const val PASSWORD = "password"; const val PIN = "pin"; const val PATTERN = "pattern"
        @Volatile var unlockedPkg: String? = null
    }
}
